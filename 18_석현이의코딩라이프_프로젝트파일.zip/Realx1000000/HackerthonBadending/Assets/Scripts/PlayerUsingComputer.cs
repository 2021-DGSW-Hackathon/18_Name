﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerUsingComputer : MonoBehaviour
{
    public string usingComputer = "LG 그램";


}
